<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['account_logbook_fields'] = 'Pola logu';
$lang['account_column1_text'] = 'Kolumna 1';
$lang['account_column2_text'] = 'Kolumna 2';
$lang['account_column3_text'] = 'Kolumna 3';
$lang['account_column4_text'] = 'Kolumna 4';
$lang['account_column5_text'] = 'Kolumna 5 (tylko dla logu)';
