<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// Tiles
$lang['qslcard_string_your_are_using'] = 'Używasz';
$lang['qslcard_string_disk_space'] = 'żeby przechować dane kart QSL';

$lang['qslcard_info'] = 'QSL Info';
$lang['qslcard_sent_bureau'] = 'Karta QSL została wysłana przez biuro';
$lang['qslcard_sent_direct'] = 'Karta QSL została wysłana bezpośrednio';
$lang['qslcard_recv_bureau'] = 'Karta QSL została otrzymana przez biuro';
$lang['qslcard_recv_direct'] = 'Karta QSL została otrzymana bezpośrednio';

$lang['qslcard_upload_front'] = 'Wyślij awers karty QSL';
$lang['qslcard_upload_back'] = 'Wyślij rewers karty QSL';

$lang['qslcard_upload_button'] = 'Wyślij informacje.';
