<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['contesting_page_title'] = 'Logowanie Zawodów';
$lang['contesting_button_reset_contest_session'] = 'Wyczyść sesje';

$lang['contesting_exchange_type'] = 'Typ wymiany';
$lang['contesting_exchange_type_serial'] = 'Numeracja';
$lang['contesting_exchange_type_other'] = 'Inne';

$lang['contesting_contest_name'] = 'Nazwa Zawodów';

$lang['contesting_btn_reset_qso'] = 'Wyczyść łączność';
$lang['contesting_btn_save_qso'] = 'Zapisz łączność';

$lang['contesting_title_callsign_suggestions'] = 'Podpowiadanie znaków';
$lang['contesting_title_contest_logbook'] = 'Log zawodów';